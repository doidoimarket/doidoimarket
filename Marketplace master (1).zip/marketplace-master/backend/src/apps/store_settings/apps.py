from django.apps import AppConfig


class StoreSettingsConfig(AppConfig):
    name = 'apps.store_settings'
    verbose_name = 'Настройки маркета'
