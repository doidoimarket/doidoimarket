from rest_framework import serializers
from rest_framework_recursive.fields import RecursiveField

from apps.products import models
from apps.products.tasks import notify_about_product_upgrade


class CategorySerializer(serializers.HyperlinkedModelSerializer):
    children = RecursiveField(many=True)

    class Meta:
        model = models.Category
        fields = (
            'id', 'slug', 'title', 'children', 'description', 'image'
        )


class ReviewSerializer(serializers.ModelSerializer):
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = models.Review
        fields = ('id', 'product', 'comment', 'stars', 'user')


class ProductSpecificationValueSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductSpecificationValue
        fields = ('id', 'specification', 'value')


class ProductSpecificationSerializer(serializers.ModelSerializer):
    product_specifications_values = ProductSpecificationValueSerializer(many=True)

    class Meta:
        model = models.ProductSpecification
        fields = ('id', 'name', 'category', 'product_specifications_values')


class ProductImageSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.ProductImage
        fields = '__all__'


class ProductSerializer(serializers.ModelSerializer):
    reviews = ReviewSerializer(many=True, read_only=True)
    reviews_count = serializers.IntegerField(read_only=True)
    average_rating = serializers.IntegerField(read_only=True)
    shop = serializers.SlugRelatedField(
        read_only=True,
        slug_field='shop_id'
    )
    shop_name = serializers.CharField(read_only=True)
    in_stock = serializers.BooleanField(read_only=True)
    images = ProductImageSerializer(read_only=True, many=True)
    actual_retail_price = serializers.DecimalField(decimal_places=2, max_digits=10, read_only=True)
    actual_wholesale_price = serializers.DecimalField(decimal_places=2, max_digits=10, read_only=True)
    extra_charge_retail = serializers.DecimalField(decimal_places=2, max_digits=10, read_only=True)
    extra_charge_wholesale = serializers.DecimalField(decimal_places=2, max_digits=10, read_only=True)
    shop_logo = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = models.Product
        fields = '__all__'

    def get_shop_logo(self, obj):
        return obj.shop.logo.url


class AutoCompleteProductsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Product
        fields = ('id', 'title', 'slug', 'article')


class ProductUpgradeDaySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ProductUpgradeDay
        fields = '__all__'


class UpgradeProductPaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.UpgradeProductPayment
        fields = '__all__'


class ProductUpgradeRequestSerializer(serializers.ModelSerializer):
    shop = serializers.SlugRelatedField(slug_field='shop_id', read_only=True)

    class Meta:
        model = models.ProductUpgradeRequest
        fields = '__all__'
        read_only_fields = ('request_id', 'id', 'sum', 'paid', 'is_active', 'created_at')

    def validate(self, attrs):
        product_article = attrs.get('product_article')
        if not models.Product.objects.filter(article=product_article).exists():
            raise serializers.ValidationError({'product_article': 'Не существующий артикул товара'})
        return attrs

    def create(self, validated_data):
        instance = super().create(validated_data)
        notify_about_product_upgrade.delay(
            instance.product_article,
            instance.request_id,
            instance.days.days,
            instance.payment_type.name,
            instance.sum,
            instance.shop.shop_id
        )
        return instance


class ReviewsCountByStarSerializer(serializers.Serializer):
    stars = serializers.IntegerField()
    rate_count = serializers.IntegerField()
