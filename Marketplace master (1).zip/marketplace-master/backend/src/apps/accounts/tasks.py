from django.core.mail import send_mail
from src.settings import EMAIL_HOST_USER
from src.celery import app
from django.conf import settings
from apps.accounts import models


@app.task
def notify_about_shop_creation(shop_id):
    send_mail(
        "Новая заявка на создание магазина",
        f"ID Магазина - {shop_id}",
        EMAIL_HOST_USER,
        settings.ADMIN_EMAILS,
        fail_silently=False,
    )


@app.task
def notify_about_order(data, shop_emails):
    text = """
     ID Заказа - {0}
     Номер телефона - {1}
     Тип оплаты - {2}
     Комментарии - {3}
     Имя заказчика - {4}
    """.format(data['order_id'], data['phone_number'], data['payment_type'], data['comment'], data['user_info'])
    send_mail(
        "Новый заказ. Проверьте личный кабинет",
        text,
        EMAIL_HOST_USER,
        settings.ADMIN_EMAILS + shop_emails,
        fail_silently=False,
    )


@app.task
def deactivate_shop(shop_id, shop_email):
    models.Shop.objects.filter(shop_id=shop_id).update(is_active=False, subscription_fee=False)
    send_mail(
        "Уведомление о деактивации",
        f"Ваш магазин был деактивирован из-за неуплаты абонентской платы. Пожалуйста свяжитесь с менеджером",
        EMAIL_HOST_USER,
        shop_email,
        fail_silently=False,
    )
