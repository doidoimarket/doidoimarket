SELLER = 'S'
BUYER = 'B'
USER_TYPE_CHOICES = (
    (SELLER, 'Продавец'),
    (BUYER, 'Покупатель')
)


WHOLESALE = 'W'
RETAIL = 'R'
SELLING_TYPE_CHOICES = (
    (WHOLESALE, 'Оптовый'),
    (RETAIL, 'Розничный'),
)


JURIDICAL = 'J'
INDIVIDUAL = 'I'
SHOP_OWNER_TYPE_CHOICES = (
    (JURIDICAL, 'Юридическое лицо'),
    (INDIVIDUAL, 'Индивидуальный предприниматель')
)


PAYBOX = 'PAYBOX'
CASH = 'CASH'
PAYMENT_TYPE = (
    (PAYBOX, PAYBOX),
    (CASH, 'Наличные')
)
