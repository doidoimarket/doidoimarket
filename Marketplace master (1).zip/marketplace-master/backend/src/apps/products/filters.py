import django_filters
from apps.products import models


class ProductFilter(django_filters.FilterSet):
    actual_retail_price = django_filters.RangeFilter()
    actual_wholesale_price = django_filters.RangeFilter()

    class Meta:
        model = models.Product
        fields = [
            'retail', 'wholesale', 'shop', 'featured',
            'actual_wholesale_price', 'actual_retail_price',
            'product_specifications_values', 'is_active', 'region'
        ]
