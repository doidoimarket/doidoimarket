import nested_admin
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.utils.translation import gettext_lazy as _
from apps.accounts import models, inlines
from apps.products import inlines as product_inlines
from rangefilter.filters import DateRangeFilter


User = get_user_model()


@admin.register(User)
class UserAdmin(nested_admin.NestedModelAdmin, UserAdmin):
    list_display = (
        'email', 'is_superuser', 'user_type', 'is_active', 'phone_number'
    )
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        (_('Personal info'), {'fields': (
            'first_name', 'last_name', 'user_type', 'phone_number'
        )}),
        (_('Permissions'), {
            'fields': ('is_active', 'is_superuser', 'is_staff'),
        }),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2', 'is_staff', 'is_active')}
        ),
    )
    search_fields = ('email', 'first_name', 'last_name', 'shop__name', 'phone_number')
    ordering = ('email',)
    inlines = [inlines.ShopInline]


@admin.register(models.Shop)
class ShopAdmin(admin.ModelAdmin):
    list_display = [
        'shop_id', 'user', 'name', 'retail', 'wholesale',
        'owner_type', 'is_active', 'created', 'phone_number',
        'subscription_fee', 'address'
    ]
    # readonly_fields = (
    #     'shop_id', 'logo', 'patent', 'owner_full_name',
    #     'name', 'description', 'owner_type', 'inn'
    # )
    readonly_fields = (
        'shop_id',
    )
    search_fields = ['shop_id', 'name', 'inn', 'owner_full_name', 'phone_number']
    list_filter = ['owner_type', 'retail', 'wholesale', 'subscription_fee', ('created', DateRangeFilter)]
    inlines = [product_inlines.ProductInline]


@admin.register(models.Order)
class OrderAdmin(admin.ModelAdmin):
    filter_horizontal = ('shops',)
    inlines = [
        inlines.OrderItemInline
    ]
    list_display = [
        'order_id', 'payment_type', 'phone_number', 'paid',
        'delivered', 'created', 'self_delivered', 'self_deliver_address',
        'country', 'city', 'street', 'house_number', 'user_info', 'get_cost'
    ]

    def get_cost(self, obj):
        return obj.total_cost


@admin.register(models.OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = [
        'get_product_article', 'get_product_title', 'quantity',
        'get_total_price', 'created', 'get_profit',
        'get_paybox_commission', 'get_seller_profit'
    ]
    fields = (
        'product', 'get_product_title', 'quantity',
        'get_total_price', 'created')
    readonly_fields = (
        'created', 'get_product_article', 'get_product_title',
        'get_total_price', 'get_profit', 'get_paybox_commission',
        'get_seller_profit'
    )
    list_filter = [('created', DateRangeFilter)]

    def get_product_article(self, obj):
        return obj.product.article

    def get_product_title(self, obj):
        return obj.product.title

    def get_profit(self, obj):
        return obj.get_market_profit()

    def get_total_price(self, obj):
        return obj.get_cost()

    def get_paybox_commission(self, obj):
        return obj.get_paybox_commission()

    def get_seller_profit(self, obj):
        return obj.get_seller_profit()

    get_product_article.short_description = 'Артикул товара'
    get_profit.short_description = 'Прибыль платформы'
    get_paybox_commission.short_description = 'Процент paybox'
    get_seller_profit.short_description = 'Прибыль продавца'
    get_total_price.short_description = 'Общая сумма'
    get_product_title.short_description = 'Наименование товара'


admin.site.unregister(Group)
admin.site.register(models.SelfDeliver)

admin.site.site_header = "DOIDOI SHOP"
admin.site.site_title = "DOIDOI SHOP"
admin.site.index_title = "DOIDOI SHOP"
