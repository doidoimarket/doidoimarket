export const $USER_ROLES = {
  SELLLER: "S",
  USER: "B",
  ADMIN: "admin",
}

export const API_BASE_URL = process.env.REACT_APP_API_URL || "https://doidoi.shop/api/v1";