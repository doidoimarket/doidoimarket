from apps.utils import permissions as cm_permissions
from rest_framework import permissions


class SwaggerErrorMixin:
    def get_parsers(self):
        if getattr(self, 'swagger_fake_view', False):
            return []
        return super().get_parsers()


class IsSellerMixin:
    def get_permissions(self):
        if self.action in ['update', 'destroy', 'partial_update']:
            return [permissions.IsAuthenticated(), cm_permissions.IsSeller()]
        return []
