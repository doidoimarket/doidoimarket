from django.contrib.auth import get_user_model
from django.db.models import Prefetch, F
from rest_framework import viewsets, permissions, mixins, generics
from rest_framework.generics import get_object_or_404
from apps.accounts import models, serializers
from apps.products.serializers import ReviewSerializer
from apps.products.models import Review
from apps.utils.mixins import SwaggerErrorMixin
from apps.utils import permissions as cs_permissions
from apps.utils.mixins import IsSellerMixin
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.decorators import action
from rest_framework.filters import OrderingFilter, SearchFilter

User = get_user_model()


class ShopViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = models.Shop.objects.all().prefetch_related('products')
    serializer_class = serializers.ShopSerializer
    lookup_field = 'shop_id'


class MyShopReviewViewSet(SwaggerErrorMixin, viewsets.ReadOnlyModelViewSet):
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticated, cs_permissions.IsSeller]
    filter_backends = [DjangoFilterBackend, OrderingFilter, SearchFilter]
    filterset_fields = ['stars']
    search_fields = ['comment', 'product__article', 'product__title']

    def get_queryset(self):
        return Review.objects.filter(product__shop=self.request.user.shop)


class MyShopViewSet(viewsets.ModelViewSet):
    serializer_class = serializers.MyShopSerializer
    queryset = models.Shop.objects.all()
    lookup_field = 'shop_id'
    permission_classes = [permissions.IsAuthenticated, cs_permissions.IsSeller, cs_permissions.IsActivatedShop]

    def list(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def get_object(self):
        return get_object_or_404(models.Shop.objects.filter(user=self.request.user))


class CurrentUserViewSet(mixins.ListModelMixin,
                         mixins.RetrieveModelMixin,
                         mixins.DestroyModelMixin,
                         mixins.UpdateModelMixin,
                         viewsets.GenericViewSet):
    serializer_class = serializers.CustomUserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return User.objects.filter(pk=self.request.user.pk)

    def get_object(self):
        return self.request.user

    def list(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    @action(["get", "put", "patch", "delete"], detail=False)
    def me(self, request, *args, **kwargs):
        if request.method == "GET":
            return self.retrieve(request, *args, **kwargs)
        elif request.method == "PUT":
            return self.update(request, *args, **kwargs)
        elif request.method == "PATCH":
            return self.partial_update(request, *args, **kwargs)
        elif request.method == "DELETE":
            return self.destroy(request, *args, **kwargs)


class SelfDeliverViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = models.SelfDeliver.objects.all()
    serializer_class = serializers.SelfDeliverSerializer


class OrderViewSet(IsSellerMixin, viewsets.ModelViewSet):
    queryset = models.Order.objects.all()

    def perform_create(self, serializer):
        user = self.request.user
        if not user.is_anonymous:
            serializer.save(user=self.request.user)
        serializer.save()

    def get_serializer_class(self):
        if self.action == 'create':
            return serializers.OrderCreateSerializer
        return serializers.OrderSerializer


class OrderItemViewSet(IsSellerMixin, viewsets.ModelViewSet):
    queryset = models.OrderItem.objects.all()
    serializer_class = serializers.OrderItemSerializer


class MyOrdersViewSet(viewsets.ModelViewSet):
    serializer_class = serializers.MyOrdersSerializer
    lookup_field = 'order_id'
    filter_backends = [DjangoFilterBackend, OrderingFilter, SearchFilter]
    filterset_fields = ['paid', 'delivered', 'payment_type', 'self_delivered', 'canceled']
    search_fields = ['order_id', 'phone_number']
    permission_classes = [permissions.IsAuthenticated, cs_permissions.IsSeller]

    def get_queryset(self):
        return models.Order.objects.filter(
            shops=self.request.user.shop
        ).annotate(self_deliver_address_name=F('self_deliver_address__address')).prefetch_related(
            Prefetch(
                'items',
                queryset=models.OrderItem.objects.filter(
                    product__shop=self.request.user.shop
                )
            )
        )


class PayBoxInitAPIView(generics.CreateAPIView):
    serializer_class = serializers.PayBoxInitSerializer



class PayBoxCheckPaymentAPIView(generics.CreateAPIView):
    serializer_class = serializers.PayboxPaymentCheck

