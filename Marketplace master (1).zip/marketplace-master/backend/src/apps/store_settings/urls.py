from rest_framework.routers import DefaultRouter
from apps.store_settings import views


router = DefaultRouter()
router.register('services', views.ServiceViewSet, basename='services')
router.register('banners_one', views.Banner1ViewSet, basename='banners_1')
router.register('banners_two', views.Banner2ViewSet, basename='banners_2')
router.register('banners_three', views.Banner3ViewSet, basename='banners_3')
router.register('contact_info', views.ContactInfoViewSet, basename='contact_info')
router.register('faq', views.FAQViewSet, basename='faq')
router.register('agreement', views.AgreementViewSet, basename='agreement')
router.register('privacy_policy', views.PrivacyPolicyViewSet, basename='privacy_policy')
router.register('public_offer', views.PublicOfferViewSet, basename='public_offer')
router.register('vacancy', views.VacancyViewSet, basename='vacancy')
router.register('partner_program', views.PartnerProgramViewSet, basename='partner_program')
router.register('cooperation', views.CooperationViewSet, basename='cooperation')
router.register('delivery_info', views.DeliveryInfoViewSet, basename='delivery_info')
router.register('about_us', views.AboutUsViewSet, basename='about_us')
router.register('banner_for_sale', views.BannerForSaleViewSet, basename='banner_for_sale')
router.register('banners_for_ad', views.BannerForAdViewSet, basename='banners_for_ad')


urlpatterns = []

urlpatterns += router.urls
