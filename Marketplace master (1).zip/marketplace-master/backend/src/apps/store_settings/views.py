from rest_framework import viewsets, mixins

from apps.store_settings import serializers, models


class ServiceViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = models.Service.objects.all()
    serializer_class = serializers.ServiceSerializer


class Banner1ViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.BannerSerializer
    queryset = models.Banner1.objects.all()


class Banner2ViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.BannerSerializer
    queryset = models.Banner2.objects.all()


class Banner3ViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.BannerSerializer
    queryset = models.Banner3.objects.all()


class ContactInfoViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.ContactInfoSerializer
    queryset = models.ContactInfo.objects.all()


class FAQViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.FAQSerializer
    queryset = models.FAQ.objects.all()


class AgreementViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.AgreementSerializer
    queryset = models.Agreement.objects.all()


class PublicOfferViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.PublicOfferSerializer
    queryset = models.PublicOffer.objects.all()


class PrivacyPolicyViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.PrivacyPolicySerializer
    queryset = models.PrivacyPolicy.objects.all()


class CooperationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.CooperationSerializer
    queryset = models.Cooperation.objects.all()


class VacancyViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.VacancySerializer
    queryset = models.Vacancy.objects.all()


class PartnerProgramViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.PartnerProgramSerializer
    queryset = models.PartnerProgram.objects.all()


class DeliveryInfoViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.DeliveryInfoSerializer
    queryset = models.DeliveryInfo.objects.all()


class AboutUsViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.AboutUsSerializer
    queryset = models.AboutUs.objects.all()


class BannerForSaleViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.BannerForSaleSerializer
    queryset = models.BannerForSale.objects.all()


class BannerForAdViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.BannerForAdSerializer
    queryset = models.AdBanner.objects.all()
