from rest_framework.routers import DefaultRouter
from django.urls import path
from apps.accounts import views


router = DefaultRouter()
router.register('my_shop', views.MyShopViewSet, basename='shop')
router.register('users', views.CurrentUserViewSet, basename='users')
router.register('shops', views.ShopViewSet, basename='shops')
router.register('my_shop_reviews', views.MyShopReviewViewSet, basename='my_shop_reviews')
router.register('orders', views.OrderViewSet, basename='orders')
router.register('my_orders', views.MyOrdersViewSet, basename='orders')
router.register('order_items', views.OrderItemViewSet, basename='order_items')
router.register('self_deliver_addresses', views.SelfDeliverViewSet, basename='self_deliver_addresses')


urlpatterns = [
    path('paybox/init/', views.PayBoxInitAPIView.as_view(), name='paybox-init'),
    path('paybox/payment/check/', views.PayBoxCheckPaymentAPIView.as_view(), name='paybox-check')
]
urlpatterns += router.urls
