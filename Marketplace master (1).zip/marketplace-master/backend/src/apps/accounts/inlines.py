from apps.accounts import models
from django.contrib import admin
import nested_admin


class ShopInline(nested_admin.NestedStackedInline):
    model = models.Shop
    extra = 0


class OrderItemInline(admin.TabularInline):
    model = models.OrderItem
    extra = 0
