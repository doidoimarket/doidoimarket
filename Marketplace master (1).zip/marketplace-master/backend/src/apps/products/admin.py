import nested_admin
from django.contrib import admin
from mptt.admin import DraggableMPTTAdmin
from rangefilter.filters import DateRangeFilter
from apps.products import models
from apps.products import inlines


@admin.register(models.Category)
class CategoryAdmin(DraggableMPTTAdmin):
    list_display = ('tree_actions', 'indented_title')
    list_display_links = ('indented_title',)
    list_filter = ['parent']
    search_fields = ['title', 'description']
    readonly_fields = ('slug',)


@admin.register(models.Product)
class ProductAdmin(nested_admin.NestedModelAdmin):
    list_display = [
        'article', 'title', 'created_at', 'retail', 'wholesale',
        'is_active', 'get_average_rating', 'featured'
    ]
    search_fields = [
        'article', 'title', 'description'
    ]
    list_filter = [
        'retail', 'wholesale', 'is_active', 'featured',
        'shop__shop_id', 'category__title',
        ('created_at', DateRangeFilter),
    ]
    inlines = [
        inlines.ProductImageInline,
        inlines.ProductReviewsInline
    ]
    readonly_fields = ('actual_retail_price', 'actual_wholesale_price')

    def get_average_rating(self, obj):
        return obj.average_rating

    get_average_rating.short_description = 'Средний рейтинг'


@admin.register(models.Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['comment', 'stars', 'created_at', 'user']
    list_filter = [
        'user__email', 'stars', 'product__article',
        ('created_at', DateRangeFilter),
    ]
    search_fields = ['user__email', 'stars', 'product__article', 'comment']


@admin.register(models.UpgradeProductPayment)
class UpgradeProductPaymentAdmin(admin.ModelAdmin):
    list_display = ['name', 'account_number']


@admin.register(models.ProductUpgradeRequest)
class ProductUpgradeRequestAdmin(admin.ModelAdmin):
    list_display = [
        'request_id', 'product_article', 'payment_type', 'sum',
        'days', 'paid', 'is_active', 'created_at'
    ]
    list_filter = [
        'payment_type', 'days', 'paid', 'is_active',
        ('created_at', DateRangeFilter),
    ]
    search_fields = ['request_id', 'product_article', 'sum', 'days']


@admin.register(models.ProductUpgradeDay)
class ProductUpgradeDayAdmin(admin.ModelAdmin):
    list_display = ['days', 'price']


@admin.register(models.ProductSpecification)
class ProductSpecificationAdmin(admin.ModelAdmin):
    list_display = ['name']
    inlines = [
        inlines.ProductSpecificationValueInline
    ]


admin.site.register(models.ProductSpecificationValue)
admin.site.register(models.ProductViewCount)
