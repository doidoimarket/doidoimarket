from rest_framework import serializers

from apps.store_settings import models


class BannerSerializer(serializers.Serializer):
    image = serializers.ImageField()
    link_to_product = serializers.URLField()


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Service
        fields = '__all__'


class ContactInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.ContactInfo
        fields = '__all__'


class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.FAQ
        fields = '__all__'


class PublicOfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PublicOffer
        fields = '__all__'


class PrivacyPolicySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PrivacyPolicy
        fields = '__all__'


class AgreementSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Agreement
        fields = '__all__'


class DeliveryInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.DeliveryInfo
        fields = '__all__'


class PartnerProgramSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.PartnerProgram
        fields = '__all__'


class VacancySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Vacancy
        fields = '__all__'


class CooperationSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Cooperation
        fields = '__all__'


class AboutUsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.AboutUs
        fields = '__all__'


class BannerForSaleSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.BannerForSale
        fields = '__all__'


class BannerForAdSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.AdBanner
        fields = '__all__'
