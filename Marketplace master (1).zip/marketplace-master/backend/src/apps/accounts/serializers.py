import hashlib
import requests
from django.contrib.auth import get_user_model
from rest_framework.response import Response
from rest_framework.validators import UniqueValidator
from rest_framework import serializers
from djoser.serializers import UserCreateSerializer

from apps.accounts import models, constants
from apps.accounts.tasks import notify_about_shop_creation, notify_about_order
from apps.products.serializers import ProductSerializer
from apps.utils.helpers import random_string

User = get_user_model()


class ShopSerializer(serializers.ModelSerializer):
    products = ProductSerializer(many=True, read_only=True)

    class Meta:
        model = models.Shop
        fields = ('shop_id', 'name', 'logo', 'description', 'products', 'phone_number')


class MyShopSerializer(serializers.ModelSerializer):
    shop_id = serializers.CharField(
        max_length=10,
        validators=[UniqueValidator(queryset=models.Shop.objects.all())],
        read_only=True
    )
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = models.Shop
        fields = '__all__'
        read_only_fields = ('is_active', 'user', 'created')

    def create(self, validated_data):
        instance = super().create(validated_data)
        notify_about_shop_creation.delay(instance.shop_id)
        return instance


class CustomUserCreateSerializer(UserCreateSerializer):
    user_type = serializers.ChoiceField(choices=constants.USER_TYPE_CHOICES)
    phone_number = serializers.CharField()

    class Meta(UserCreateSerializer.Meta):
        fields = ('email', 'password', 'user_type', 'phone_number')


class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('email', 'user_type', 'is_active', 'first_name', 'last_name', 'phone_number')
        read_only_fields = ('email', 'user_type', 'is_active')


class SelfDeliverSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.SelfDeliver
        fields = ('id', 'address')


class OrderItemSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.OrderItem
        fields = '__all__'
    
    def create(self, validated_data):
        instance = super().create(validated_data)
        shop = instance.product.shop
        if shop not in instance.order.shops.all():
            instance.order.shops.add(shop)
        return instance


class OrderItemSerializer2(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)

    class Meta:
        model = models.OrderItem
        fields = '__all__'


class OrderSerializer(serializers.ModelSerializer):
    payment_id = serializers.CharField(read_only=True)
    order_items = OrderItemSerializer(many=True, read_only=True)
    total_cost = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)
    items = OrderItemSerializer2(many=True, read_only=True)

    class Meta:
        model = models.Order
        fields = '__all__'


class OrderCreateSerializer(serializers.ModelSerializer):
    total_cost = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        model = models.Order
        fields = (
            'id', 'order_id', 'country', 'city', 'street', 'oblast',
            'house_number', 'phone_number', 'user_info',
            'self_delivered', 'self_deliver_address',
            'total_cost', 'user', 'payment_type', 'comment'
        )
        read_only_fields = ('user',)

    def create(self, validated_data):
        instance = super().create(validated_data)
        shop_emails = [shop.user.email for shop in instance.shops.all()]
        data = {
            'order_id': instance.order_id,
            'phone_number': instance.phone_number,
            'payment_type': instance.payment_type,
            'comment': instance.comment,
            'user_info': instance.user_info
        }
        notify_about_order.delay(data, shop_emails)
        return instance


class MyOrdersSerializer(serializers.ModelSerializer):
    total_cost = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)
    items = OrderItemSerializer2(many=True, read_only=True)
    self_deliver_address_name = serializers.CharField(read_only=True)
    product_specifications = serializers.JSONField(read_only=True)

    class Meta:
        model = models.Order
        fields = (
            'id', 'order_id', 'country', 'oblast', 'user_info', 'city', 'city', 'street', 'house_number',
            'paid', 'delivered', 'payment_type', 'created', 'updated', 'phone_number',
            'self_delivered', 'self_deliver_address', 'self_deliver_address_name',
            'shops', 'user', 'items', 'total_cost', 'canceled', 'comment', 'product_specifications'
        )


class PayBoxInitSerializer(serializers.Serializer):
    pg_order_id = serializers.CharField()
    pg_merchant_id = serializers.CharField()
    pg_amount = serializers.DecimalField(max_digits=10, decimal_places=2)
    pg_testing_mode = serializers.IntegerField(required=False, default=1)
    pg_currency = serializers.CharField()
    pg_description = serializers.CharField()

    def create(self, validated_data):
        validated_data['pg_salt'] = random_string()
        pg_sig = f"init_payment.php;{validated_data['pg_amount']};{validated_data['pg_currency']};{validated_data['pg_description']};{validated_data['pg_merchant_id']};{validated_data['pg_order_id']};{validated_data['pg_salt']};{validated_data['pg_testing_mode']};wvPjxMzqsldkCtsS"
        validated_data['pg_sig'] = hashlib.md5(pg_sig.encode()).hexdigest()
        url = 'https://api.paybox.money/init_payment.php'
        response = requests.post(url, data=validated_data)
        self._data = {'content': response.text}
        return self._data


class PayboxPaymentCheck(serializers.Serializer):
    pg_order_id=serializers.IntegerField()
    pg_payment_id=serializers.IntegerField()
    pg_amount=serializers.IntegerField()

    def create(self, validated_data):
        if not models.Order.objects.filter(order_id=validated_data.get('pg_order_id')).exists():
            raise serializers.ValidationError({'хуй тебе'})
        order = models.Order.objects.get(order_id=validated_data.get('pg_order_id'))
        if order.total_cost == float(validated_data.get('pg_amount')):
            order.payment_id = validated_data.get('pg_payment_id')
            return Response(200)
