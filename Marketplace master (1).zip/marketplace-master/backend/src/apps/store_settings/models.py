from django.db import models

from apps.utils.validators import phone_number_regex
from src.storage_backends import PublicMediaStorage
from ckeditor.fields import RichTextField


class SingletonModel(models.Model):
    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        self.pk = 1
        super(SingletonModel, self).save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        pass

    @classmethod
    def load(cls):
        obj, created = cls.objects.get_or_create(pk=1)
        return obj


class Service(models.Model):
    name = models.CharField(max_length=255, verbose_name='Название сервиса')
    logo = models.ImageField(verbose_name='Логотип', storage=PublicMediaStorage(), null=True, blank=True)
    description = models.TextField(verbose_name='Описание')
    link = models.URLField(verbose_name='Ссылка', null=True, blank=True)

    class Meta:
        verbose_name = 'Наш сервис'
        verbose_name_plural = 'Наши сервисы'

    def __str__(self):
        return self.name


class Banner1(models.Model):
    image = models.ImageField(
        upload_to=PublicMediaStorage(),
        verbose_name='Изображение',
        help_text='Загрузите изображение для большого баннера'
    )
    link_to_product = models.URLField(
        verbose_name='Ссылка на товар',
        help_text='(если баннер относится к товару)',
        null=True, blank=True
    )

    class Meta:
        verbose_name = 'Большой баннер'
        verbose_name_plural = 'Большие баннеры'

    def __str__(self):
        return f'Баннер 1 - {self.id}'


class Banner2(models.Model):
    image = models.ImageField(
        upload_to=PublicMediaStorage(),
        verbose_name='Изображение',
        help_text='Загрузите изображение для первого маленького баннера'
    )
    link_to_product = models.URLField(
        verbose_name='Ссылка на товар',
        help_text='(если баннер относится к товару)',
        null=True, blank=True
    )

    class Meta:
        verbose_name = 'Маленький баннер 1'
        verbose_name_plural = 'Маленький баннеры 1'

    def __str__(self):
        return f'Баннер 2 - {self.id}'


class Banner3(models.Model):
    image = models.ImageField(
        upload_to=PublicMediaStorage(),
        verbose_name='Изображение',
        help_text='Загрузите изображение для второго маленького баннера'
    )
    link_to_product = models.URLField(
        verbose_name='Ссылка на товар',
        help_text='(если баннер относится к товару)',
        null=True, blank=True
    )

    class Meta:
        verbose_name = 'Маленький баннер 3'
        verbose_name_plural = 'Маленький баннеры 3'

    def __str__(self):
        return f'Баннер 3 - {self.id}'


class ContactInfo(models.Model):
    name = models.CharField(max_length=255, verbose_name='Название')
    inn = models.CharField(max_length=255, verbose_name='ИНН', null=True, blank=True)
    address = models.CharField(verbose_name='Адрес', max_length=500, null=True, blank=True)
    phone_number = models.CharField(
        max_length=13,
        validators=[phone_number_regex],
        verbose_name='Номер телефона',
        null=True, blank=True
    )
    email = models.EmailField(verbose_name='Email', null=True, blank=True)
    telegram = models.CharField(max_length=255, verbose_name='Телеграм', null=True, blank=True)
    instagram = models.CharField(max_length=255, verbose_name='Инстаграм', null=True, blank=True)
    facebook = models.CharField(max_length=255, verbose_name='Facebook', null=True, blank=True)
    whatsapp = models.CharField(max_length=255, verbose_name='Whatsapp', null=True, blank=True)

    def __str__(self):
        return self.address

    class Meta:
        verbose_name = 'Контакты'
        verbose_name_plural = 'Контакты'


class FAQ(models.Model):
    question = models.TextField(verbose_name='Вопрос')
    answer = RichTextField(verbose_name='Ответ')

    class Meta:
        verbose_name = 'Часто задаваемый вопрос'
        verbose_name_plural = 'Часто задаваемые вопросы'

    def __str__(self):
        return self.question


class Agreement(SingletonModel):
    file = models.FileField(upload_to=PublicMediaStorage(), verbose_name='Договор с продавцами')

    class Meta:
        verbose_name = 'Договор с продавцами'
        verbose_name_plural = 'Договоры с продавцами'

    def __str__(self):
        return str(self.id)


class PublicOffer(SingletonModel):
    file = models.FileField(upload_to=PublicMediaStorage(), verbose_name='Публичная оферта')

    class Meta:
        verbose_name = 'Публичная оферта'
        verbose_name_plural = 'Публичная оферта'

    def __str__(self):
        return str(self.id)


class PrivacyPolicy(SingletonModel):
    file = models.FileField(upload_to=PublicMediaStorage(), verbose_name='Политика конфиденциальности')

    class Meta:
        verbose_name = 'Политика конфиденциальности'
        verbose_name_plural = 'Политика конфиденциальности'

    def __str__(self):
        return str(self.id)


class PartnerProgram(SingletonModel):
    content = RichTextField(verbose_name='Партнерская программа', null=True, config_name='default')

    class Meta:
        verbose_name = 'Партнерская программа'
        verbose_name_plural = 'Партнерская программа'

    def __str__(self):
        return str(self.id)


class Vacancy(SingletonModel):
    content = RichTextField(verbose_name='Описание', null=True, config_name='default')

    class Meta:
        verbose_name = 'Вакансия'
        verbose_name_plural = 'Вакансии'

    def __str__(self):
        return str(self.id)


class DeliveryInfo(SingletonModel):
    content = RichTextField(verbose_name='Информация о доставке', null=True, config_name='default')

    class Meta:
        verbose_name = 'Информация о доставке'
        verbose_name_plural = 'Информации о доставке'

    def __str__(self):
        return str(self.id)


class Cooperation(SingletonModel):
    content = RichTextField(verbose_name='Информация о сотрудничестве', null=True, config_name='default')

    class Meta:
        verbose_name = 'Информация о сотрудничестве'
        verbose_name_plural = 'Информация о сотрудничестве'

    def __str__(self):
        return str(self.id)


class AboutUs(SingletonModel):
    content = RichTextField(verbose_name='О нас', null=True, config_name='default')

    class Meta:
        verbose_name = 'О нас'
        verbose_name_plural = 'О нас'

    def __str__(self):
        return str(self.id)


class BannerForSale(SingletonModel):
    title = models.CharField(max_length=255, null=True, blank=True, verbose_name='Главный текст')
    content = models.TextField(null=True, blank=True, verbose_name='Описание')
    image = models.ImageField(upload_to=PublicMediaStorage(), verbose_name='Изображение для фона', null=True)

    class Meta:
        verbose_name = 'Начать продавать'
        verbose_name_plural = 'Начать продавать'

    def __str__(self):
        return str(self.id)


class AdBanner(models.Model):
    image = models.ImageField(
        upload_to=PublicMediaStorage(),
        verbose_name='Изображение для рекламы',
        null=True, blank=True
    )
    link = models.URLField(
        verbose_name='Ссылка',
        null=True, blank=True
    )

    class Meta:
        verbose_name = 'Рекламный баннер'
        verbose_name_plural = 'Рекламные баннеры'

    def __str__(self):
        return f'Рекламный баннер {self.id}'
