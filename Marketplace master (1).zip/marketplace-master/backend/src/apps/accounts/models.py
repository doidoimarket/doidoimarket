from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save

from apps.accounts.managers import CustomUserManager
from apps.accounts import constants, receivers
from apps.utils import helpers
from apps.utils.validators import phone_number_regex
from src.storage_backends import PublicMediaStorage


class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True)
    user_type = models.CharField(
        max_length=255,
        choices=constants.USER_TYPE_CHOICES,
        verbose_name='Тип пользователя',
        default=constants.BUYER
    )
    phone_number = models.CharField(
        max_length=13,
        validators=[phone_number_regex],
        verbose_name='Номер телефона'
    )
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    class Meta:
        verbose_name = "Пользователь"
        verbose_name_plural = "Пользователи"
        ordering = ('-id',)

    def __str__(self):
        return self.email


class Shop(models.Model):
    name = models.CharField(max_length=255, verbose_name='Название магазина/компании')
    description = models.TextField(null=True, blank=True, verbose_name='Описание')
    owner_full_name = models.CharField(
        max_length=255,
        verbose_name='ФИО владельца/Название организации',
        blank=True, null=True
    )
    inn = models.CharField(max_length=20, verbose_name='ИНН', null=True, blank=True)
    owner_type = models.CharField(
        max_length=1, choices=constants.SHOP_OWNER_TYPE_CHOICES,
        default=constants.JURIDICAL, verbose_name='Тип владельца'
    )
    retail = models.BooleanField(default=False, verbose_name='Розница')
    wholesale = models.BooleanField(default=False, verbose_name='Оптом')
    logo = models.ImageField(storage=PublicMediaStorage(), verbose_name='Логотип')
    patent = models.FileField(
        storage=PublicMediaStorage(),
        verbose_name='Патент/свидетельство о регистрации',
        null=True, blank=True
    )
    created = models.DateTimeField(auto_now_add=True, verbose_name='Создан')
    shop_id = models.CharField(max_length=15, verbose_name='ID Магазина', null=True)
    user = models.OneToOneField('User', on_delete=models.CASCADE, verbose_name='Пользователь')
    phone_number = models.CharField(
        max_length=13,
        validators=[phone_number_regex],
        verbose_name='Номер телефона',
        null=True
    )
    is_active = models.BooleanField(default=False, verbose_name='Активный')
    subscription_fee = models.BooleanField(default=False, verbose_name='Абонентская плата')
    subscription_until = models.DateTimeField(verbose_name='Абонетская плата действует до', null=True, blank=True)
    address = models.TextField(null=True, verbose_name='Адрес магазина', blank=True)

    class Meta:
        verbose_name = 'Магазин'
        verbose_name_plural = 'Магазины'

    def save(self, *args, **kwargs):
        if not self.shop_id:
            self.shop_id = helpers.random_string()
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class SelfDeliver(models.Model):
    address = models.TextField(verbose_name='Адрес')

    class Meta:
        verbose_name = 'Адрес самовызова'
        verbose_name_plural = 'Адреса самовызова'

    def __str__(self):
        return self.address


class Order(models.Model):
    payment_id = models.CharField(max_length=255, verbose_name='ID оплаты (PayBox)', null=True, blank=True)
    order_id = models.CharField(max_length=15, verbose_name='ID заказа', editable=False)
    country = models.CharField(max_length=255, verbose_name='Страна', null=True, blank=True)
    oblast = models.CharField(max_length=255, verbose_name='Область', null=True, blank=True)
    city = models.CharField(max_length=255, verbose_name='Город/Село', null=True, blank=True)
    street = models.CharField(max_length=255, verbose_name='Улица', null=True, blank=True)
    house_number = models.CharField(max_length=255, verbose_name='Номер дома/квартиры', null=True, blank=True)
    paid = models.BooleanField(default=False, verbose_name='Оплачено', null=True, blank=True)
    delivered = models.BooleanField(default=False, verbose_name='Доставлен', null=True, blank=True)
    payment_type = models.CharField(max_length=255, verbose_name='Вариант оплаты', choices=constants.PAYMENT_TYPE)
    created = models.DateTimeField(auto_now_add=True, verbose_name='Создан')
    updated = models.DateTimeField(auto_now=True, verbose_name='Обновлен')
    comment = models.TextField(null=True, blank=True, verbose_name='Коментарии к заказу')
    phone_number = models.CharField(
        max_length=13,
        validators=[phone_number_regex],
        verbose_name='Номер телефона',
    )
    self_delivered = models.BooleanField(default=False, verbose_name='Самовывоз')
    self_deliver_address = models.ForeignKey(
        'SelfDeliver',
        on_delete=models.RESTRICT,
        related_name='orders',
        verbose_name='Адрес самовывоза',
        null=True, blank=True
    )
    shops = models.ManyToManyField('Shop', related_name='orders', blank=True, verbose_name='Магазины')
    user = models.ForeignKey(
        'User',
        related_name='users',
        on_delete=models.SET_NULL,
        verbose_name='Пользователь',
        null=True, blank=True
    )
    canceled = models.BooleanField(default=False, verbose_name='Отменен')
    user_info = models.CharField(verbose_name='ИНФО о заказчике', max_length=255, null=True, blank=True)

    class Meta:
        verbose_name = 'Заказ'
        verbose_name_plural = 'Заказы'

    def __str__(self):
        return self.order_id

    def save(self, *args, **kwargs):
        if not self.order_id:
            self.order_id = helpers.random_string()
        return super().save(*args, **kwargs)

    @property
    def total_cost(self):
        # todo: deliver price
        return sum(item.get_cost() for item in self.items.all())


class OrderItem(models.Model):
    order = models.ForeignKey('Order', related_name='items', on_delete=models.CASCADE, verbose_name='Заказ')
    product = models.ForeignKey(
        'products.Product',
        verbose_name='Товар',
        related_name='order_items',
        on_delete=models.CASCADE
    )
    quantity = models.PositiveIntegerField(default=1, verbose_name='Количество')
    created = models.DateTimeField(auto_now_add=True, verbose_name='Создан')
    product_specifications = models.JSONField(null=True, blank=True, verbose_name='Характеристики товара')

    class Meta:
        verbose_name = 'Заказанный товар'
        verbose_name_plural = 'Заказанные товары'

    def __str__(self):
        return f'{self.order.order_id}-{self.product.title}'

    def get_cost(self):
        if self.quantity >= self.product.wholesale_amount:
            return self.quantity * self.product.actual_wholesale_price
        return self.quantity * self.product.actual_retail_price

    def get_market_profit(self):
        return float(self.get_cost()) * 0.1 - float(self.get_paybox_commission())

    def get_paybox_commission(self):
        return float(self.get_cost()) * 0.029

    def get_seller_profit(self):
        return float(self.get_cost()) - float(self.get_market_profit())


post_save.connect(receivers.deactivate_after_subscription_is_ended, sender=Shop)
