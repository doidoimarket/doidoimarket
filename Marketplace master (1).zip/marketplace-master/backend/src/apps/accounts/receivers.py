from apps.accounts import tasks


def deactivate_after_subscription_is_ended(sender, instance, created, *args, **kwargs):
    if instance.subscription_fee:
        tasks.deactivate_shop.apply_async((instance.shop_id, instance.user.email), eta=instance.subscription_until)
