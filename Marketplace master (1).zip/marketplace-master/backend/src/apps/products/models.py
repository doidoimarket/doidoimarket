from django.db import models
from mptt.models import MPTTModel, TreeForeignKey
from pytils.translit import slugify
from django.db.models.signals import post_save

from apps.products import receivers, constants
from apps.utils import helpers
from src.storage_backends import PublicMediaStorage
from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db.models import Avg

User = get_user_model()


class ProductSpecification(models.Model):
    name = models.CharField(max_length=255, verbose_name='Название характеристики')
    category = models.ManyToManyField('Category', related_name='product_specifications', verbose_name='Категория')

    class Meta:
        verbose_name = 'Характеристика товара'
        verbose_name_plural = 'Характеристики товара'

    def __str__(self):
        return self.name


class ProductSpecificationValue(models.Model):
    specification = models.ForeignKey(
        'ProductSpecification',
        on_delete=models.CASCADE,
        related_name='product_specifications_values',
        verbose_name='Характеристика'
    )
    value = models.CharField(max_length=255, verbose_name='Значение характеристики')

    class Meta:
        verbose_name = 'Значение характеристики товара'
        verbose_name_plural = 'Значения характеристики товара'

    def __str__(self):
        return f'{self.specification.name}-{self.value}'


class Product(models.Model):
    article = models.CharField(max_length=255, verbose_name='Артикул товара', unique=True, editable=False)
    title = models.CharField(max_length=255, verbose_name='Название')
    description = models.TextField(verbose_name='Описание', null=True, blank=True)
    slug = models.SlugField(verbose_name='Имя для ссылки', max_length=500, unique=True, editable=False)
    region = models.CharField(max_length=255, choices=constants.REGION_CHOICES, verbose_name='Регион', null=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Создан', editable=False)
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Обновлен', editable=False)
    retail = models.BooleanField(default=False, verbose_name='Розница')
    wholesale = models.BooleanField(default=False, verbose_name='Оптом')
    wholesale_amount = models.PositiveIntegerField(verbose_name='С какого количества оптом', default=2)
    is_active = models.BooleanField(verbose_name='Активный', default=True)
    featured = models.BooleanField(default=False, verbose_name='Продвигается')
    amount = models.PositiveIntegerField(verbose_name='Количество на складе', default=0)
    address = models.TextField(null=True, blank=True, verbose_name='Адрес склада')
    extra_charge_retail = models.IntegerField(
        verbose_name='Наценка платформы в розницу (%)', default=0)
    extra_charge_wholesale = models.IntegerField(
        verbose_name='Наценка платформы оптом (%)', default=0)
    wholesale_price = models.DecimalField(
        verbose_name='Оптовая стоимость', max_digits=10, decimal_places=2, default=0, blank=True)
    new_retail_price = models.DecimalField(
        verbose_name='Новая розничная цена', max_digits=10, decimal_places=2, default=0, blank=True)
    old_retail_price = models.DecimalField(
        verbose_name='Старая розничная стоимость', max_digits=10, decimal_places=2, null=True, blank=True)
    actual_retail_price = models.DecimalField(
        verbose_name='Финальная цена на розничную продажу', max_digits=10, decimal_places=2, null=True, blank=True)
    actual_wholesale_price = models.DecimalField(
        verbose_name='Финальная цена на отповую продажу', max_digits=10, decimal_places=2, null=True, blank=True)
    shop = models.ForeignKey(
        'accounts.Shop',
        verbose_name='Магазин',
        related_name='products',
        on_delete=models.CASCADE,
        null=True, blank=True
    )
    category = models.ForeignKey(
        'Category',
        on_delete=models.RESTRICT,
        verbose_name='Категория',
        related_name='products'
    )
    product_specifications = models.ManyToManyField(
        'ProductSpecification',
        related_name='products',
        verbose_name='Характеристики товара'
    )
    product_specifications_values = models.ManyToManyField(
        'ProductSpecificationValue',
        related_name='products',
        verbose_name='Значения характеристик товара'
    )
    product_view_count = models.PositiveIntegerField(verbose_name='Количество просмотров', default=0)

    class Meta:
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'
        ordering = ('-created_at',)

    def __str__(self):
        return str(self.article)

    def save(self, *args, **kwargs):
        if not self.article:
            self.article = helpers.random_string()
        if not self.slug:
            self.slug = slugify(self.title) + "-" + self.article
        self.actual_retail_price = round(
            float(self.new_retail_price) +
            (float(self.extra_charge_retail) / 100 * float(self.new_retail_price)), 2
        )
        self.actual_wholesale_price = round(
            float(self.wholesale_price) +
            (float(self.extra_charge_wholesale) / 100 * float(self.wholesale_price)), 2
        )
        return super().save(*args, **kwargs)

    @property
    def average_rating(self):
        return self.reviews.aggregate(Avg('stars'))['stars__avg']

    @property
    def reviews_count(self):
        return self.reviews.count()

    @property
    def in_stock(self):
        return self.amount > 0


class ProductViewCount(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='product_count_view')
    ip = models.CharField(max_length=40)



class ProductImage(models.Model):
    image = models.ImageField(verbose_name='Изображение', storage=PublicMediaStorage())
    is_feature = models.BooleanField(default=False, verbose_name='Главная картинка')
    product = models.ForeignKey(
        'Product',
        on_delete=models.CASCADE,
        verbose_name='Товар',
        related_name='images',
    )

    class Meta:
        verbose_name = 'Картинка товара'
        verbose_name_plural = 'Картинки товара'

    def __str__(self):
        return f'Картинка для {self.product.article}'


class Category(MPTTModel):
    title = models.CharField(max_length=255, verbose_name='Название категории')
    slug = models.SlugField(verbose_name='Имя для ссылки', max_length=255, unique=True)
    description = models.TextField(verbose_name='Описание', null=True, blank=True)
    image = models.ImageField(verbose_name='Изображение', null=True, blank=True, storage=PublicMediaStorage())
    parent = TreeForeignKey(
        'self', on_delete=models.CASCADE,
        null=True, blank=True, related_name='children',
        verbose_name='Родительская категория'
    )

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'

    def save(self, *args, **kwargs):
        if not self.slug:
            str_ = helpers.random_string()
            self.slug = slugify(self.title) + f'-{str_}'
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.title


class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews', verbose_name='Пользователь')
    product = models.ForeignKey('Product', verbose_name='Товар', on_delete=models.CASCADE, related_name='reviews')
    comment = models.TextField(verbose_name='Комментарий')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')
    stars = models.IntegerField(
        verbose_name='Оценка',
        default=1,
        validators=[MaxValueValidator(5), MinValueValidator(1)]
    )

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'
        ordering = ('-created_at',)

    def __str__(self):
        return self.comment


class UpgradeProductPayment(models.Model):
    name = models.CharField('Название кошелька/банка', max_length=255)
    account_number = models.CharField('Расчетный счет', max_length=255)

    class Meta:
        verbose_name = 'Способ оплаты продвижения'
        verbose_name_plural = 'Способы оплаты продвижения'
        ordering = ('-id',)

    def __str__(self):
        return self.name


class ProductUpgradeDay(models.Model):
    days = models.IntegerField(verbose_name='Количество дней', default=0)
    price = models.DecimalField(verbose_name='Стоимость продвижения', max_digits=10, decimal_places=2)

    class Meta:
        verbose_name = 'Таймер продвижения'
        verbose_name_plural = 'Таймеры продвижения'
        ordering = ('days',)

    def __str__(self):
        return f'{self.days}'


class ProductUpgradeRequest(models.Model):
    product_article = models.CharField(max_length=255, verbose_name='Артикул товара')
    receipt = models.FileField(verbose_name='Квитанция', storage=PublicMediaStorage())
    request_id = models.CharField(max_length=255, verbose_name='ID заявки', unique=True, editable=False)
    sum = models.DecimalField(verbose_name='Сумма (сом)', max_digits=10, decimal_places=2, editable=False, null=True)
    paid = models.BooleanField(default=False, verbose_name='Оплачено')
    is_active = models.BooleanField(default=False, verbose_name='Активировать')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата заявки')
    shop = models.ForeignKey(
        'accounts.Shop',
        on_delete=models.SET_NULL,
        null=True,
        related_name='upgrade_requests',
        verbose_name='Магазин'
    )
    days = models.ForeignKey(
        'ProductUpgradeDay',
        verbose_name='Количество дней',
        related_name='upgrade_requests',
        on_delete=models.RESTRICT
    )
    payment_type = models.ForeignKey(
        'UpgradeProductPayment',
        on_delete=models.RESTRICT,
        related_name='requests',
        verbose_name='Вариант оплаты'
    )

    class Meta:
        verbose_name = 'Заявка на продвижение'
        verbose_name_plural = 'Заявки на продвижение'
        ordering = ('-created_at',)

    def save(self, *args, **kwargs):
        if not self.request_id:
            self.request_id = helpers.random_string()
        if not self.sum:
            self.sum = self.days.price
        return super().save(*args, **kwargs)


post_save.connect(receivers.upgrade_product, sender=ProductUpgradeRequest)
