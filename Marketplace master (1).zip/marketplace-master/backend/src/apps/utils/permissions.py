from rest_framework import permissions
from apps.accounts import constants


class IsSeller(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):
        return request.user.user_type == constants.SELLER

    def has_permission(self, request, view):
        return request.user.user_type == constants.SELLER


class IsOwner(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):
        return obj.user == request.user


class IsActivatedShop(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):
        return obj.is_active
