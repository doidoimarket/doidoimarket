from django.conf import settings
from django.core.mail import send_mail
from django.contrib.auth import get_user_model
from apps.products import models
from src.settings import EMAIL_HOST_USER
from src.celery import app

User = get_user_model()


@app.task
def notify_about_product_upgrade(product_article, request_id, days, payment_type, sum, shop_id):
    text = """
    Артикул товара - {0}
    Количество дней - {1}
    Вариант оплаты - {2}
    Сумма - {3}
    """.format(product_article, request_id, days, payment_type, sum)
    send_mail(
        f"Новая заявка на продвижение товара - {shop_id}",
        text,
        EMAIL_HOST_USER,
        [settings.ADMIN_EMAILS],
        fail_silently=False,
    )


@app.task
def deactivate_product_upgrade_after_some_time(article, request_id):
    models.Product.objects.filter(article=article).update(featured=False)
    models.ProductUpgradeRequest.objects.filter(id=request_id).update(is_active=False)
