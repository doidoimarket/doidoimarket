from django.contrib import admin

from apps.store_settings import models


admin.site.register(models.Service)
admin.site.register(models.ContactInfo)
admin.site.register(models.Banner1)
admin.site.register(models.Banner2)
admin.site.register(models.Banner3)
admin.site.register(models.FAQ)
admin.site.register(models.Agreement)
admin.site.register(models.PublicOffer)
admin.site.register(models.PrivacyPolicy)
admin.site.register(models.DeliveryInfo)
admin.site.register(models.Cooperation)
admin.site.register(models.PartnerProgram)
admin.site.register(models.Vacancy)
admin.site.register(models.AboutUs)
admin.site.register(models.BannerForSale)
admin.site.register(models.AdBanner)
