from django.db.models import Count
from django.db.models import F
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, permissions, mixins
from rest_framework.decorators import action
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response

from apps.products import models
from apps.products import serializers
from apps.products.filters import ProductFilter
from apps.products.models import ProductViewCount
from apps.utils import permissions as cm_permissions
from apps.utils.get_ip import get_client_ip
from apps.utils.mixins import IsSellerMixin
from apps.utils.mixins import SwaggerErrorMixin


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = models.Category.objects.root_nodes()
    serializer_class = serializers.CategorySerializer
    lookup_field = 'slug'
    pagination_class = None


class CategoryDetailViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = models.Category.objects.all()
    serializer_class = serializers.CategorySerializer
    lookup_field = 'slug'
    pagination_class = None


class ReviewViewSet(viewsets.ModelViewSet):
    queryset = models.Review.objects.all()
    serializer_class = serializers.ReviewSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter, SearchFilter]
    filterset_fields = ['product', 'stars']
    ordering_fields = ['stars']
    search_fields = ['comment']

    def get_permissions(self):
        if self.action in ['update', 'create', 'destroy', 'partial_update']:
            return [permissions.IsAuthenticated(), cm_permissions.IsOwner()]
        return []


class ProductImageViewSet(SwaggerErrorMixin, IsSellerMixin, viewsets.ModelViewSet):
    queryset = models.ProductImage.objects.all()
    serializer_class = serializers.ProductImageSerializer
    parser_classes = [MultiPartParser]
    filter_backends = [DjangoFilterBackend]


class ProductViewSet(IsSellerMixin, viewsets.ModelViewSet):
    serializer_class = serializers.ProductSerializer
    lookup_field = 'slug'
    filter_backends = [DjangoFilterBackend, OrderingFilter, SearchFilter]
    filterset_class = ProductFilter
    search_fields = ['title', 'description', 'article']

    @action(detail=True, methods=['get'])
    def reviews_count_by_star(self, request, slug=None):
        rate_count_dict = self.get_object() \
            .reviews.values('stars') \
            .order_by('stars') \
            .annotate(rate_count=Count('stars'))
        serializer = serializers.ReviewsCountByStarSerializer(rate_count_dict, many=True)
        return Response(serializer.data)

    def get_queryset(self):
        qs = models.Product.objects.annotate(
            shop_name=F('shop__name')
        ).prefetch_related('reviews', 'images')
        category_id = self.request.query_params.get('category')
        if category_id:
            if not models.Category.objects.filter(pk=category_id).exists():
                return qs
            category = models.Category.objects.filter(pk=category_id)
            children = category.get_descendants(include_self=True)
            qs = qs.filter(category__in=children)
        return qs

    def retrieve(self, request, *args, **kwargs):
        product = self.get_object()
        serializer = self.get_serializer(product)
        get_ip = get_client_ip(request)
        if not ProductViewCount.objects.filter(
                product=product,
                ip=get_ip):
            view = ProductViewCount(product=product, ip=get_ip,)
            view.save()
            product.product_view_count = ProductViewCount.objects.filter(product=product).count()
            product.save()
        return Response(serializer.data)

    def perform_create(self, serializer):
        serializer.save(shop=self.request.user.shop)


class ProductUpgradeRequestViewSet(SwaggerErrorMixin, viewsets.ModelViewSet):
    serializer_class = serializers.ProductUpgradeRequestSerializer
    parser_classes = [MultiPartParser]
    permission_classes = [permissions.IsAuthenticated, cm_permissions.IsSeller]

    def get_parsers(self):
        if getattr(self, 'swagger_fake_view', False):
            return []
        return super().get_parsers()

    def get_queryset(self):
        return models.ProductUpgradeRequest.objects.filter(
            shop__user=self.request.user
        )

    def perform_create(self, serializer):
        serializer.save(shop=self.request.user.shop)


class UpgradeProductPaymentViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.UpgradeProductPaymentSerializer
    queryset = models.UpgradeProductPayment.objects.all()


class ProductUpgradeDayViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.ProductUpgradeDaySerializer
    queryset = models.ProductUpgradeDay.objects.all()


class ProductSpecificationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = serializers.ProductSpecificationSerializer
    queryset = models.ProductSpecification.objects.all()
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['category']


class AutoCompleteProductsViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = models.Product.objects.all()
    serializer_class = serializers.AutoCompleteProductsSerializer
    lookup_field = 'slug'
    filter_backends = [SearchFilter]
    search_fields = ['title', 'article']


class FeaturedProductViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    serializer_class = serializers.ProductSerializer
    pagination_class = None

    def get_queryset(self):
        return models.Product.objects.filter(featured=True, is_active=True).annotate(
            shop_name=F('shop__name')
        ).prefetch_related('reviews', 'images')
