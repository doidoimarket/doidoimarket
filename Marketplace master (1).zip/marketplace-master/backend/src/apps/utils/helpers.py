import uuid


def random_string():
    return uuid.uuid4().hex[:15].upper()
