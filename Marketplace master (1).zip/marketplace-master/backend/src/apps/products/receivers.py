from apps.products import models, tasks
from datetime import datetime, timedelta


def upgrade_product(sender, instance, created, *args, **kwargs):
    if instance.is_active:
        models.Product.objects.filter(article=instance.product_article).update(featured=True)
        send_date = datetime.utcnow() + timedelta(days=instance.days.days)
        tasks.deactivate_product_upgrade_after_some_time.apply_async(
            (instance.product_article, instance.id),
            eta=send_date
        )
    else:
        models.Product.objects.filter(article=instance.product_article).update(featured=False)
