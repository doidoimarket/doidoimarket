from rest_framework.routers import DefaultRouter
from apps.products import views


router = DefaultRouter()
router.register('categories', views.CategoryViewSet, basename='category')
router.register('category-detail', views.CategoryDetailViewSet, basename='category-detail')
router.register('reviews', views.ReviewViewSet, basename='reviews')
router.register('products', views.ProductViewSet, basename='products')
router.register('featured_products', views.FeaturedProductViewSet, basename='featured_products')
router.register('products_auto_complete', views.AutoCompleteProductsViewSet, basename='auto_complete_products')
router.register('product_images', views.ProductImageViewSet, basename='product_images')
router.register('product_specifications', views.ProductSpecificationViewSet, basename='product_specifications')
router.register('product_upgrade', views.ProductUpgradeRequestViewSet, basename='product_upgrade')
router.register('product_upgrade_payment_types', views.UpgradeProductPaymentViewSet, basename='product_upgrade_payment_types')
router.register('product_upgrade_days', views.ProductUpgradeDayViewSet, basename='product_upgrade_days')


urlpatterns = []

urlpatterns += router.urls
