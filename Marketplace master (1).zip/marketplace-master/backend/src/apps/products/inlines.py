from django.contrib import admin
from apps.products import models
import nested_admin


class ProductSpecificationValueInline(nested_admin.NestedTabularInline):
    model = models.ProductSpecificationValue


class ProductSpecificationInline(nested_admin.NestedTabularInline):
    model = models.ProductSpecification.products.through


class ProductImageInline(nested_admin.NestedTabularInline):
    model = models.ProductImage
    extra = 0


class ProductInline(admin.TabularInline):
    model = models.Product
    extra = 0


class ProductReviewsInline(nested_admin.NestedTabularInline):
    model = models.Review
    extra = 0
